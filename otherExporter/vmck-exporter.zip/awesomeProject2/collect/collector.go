package collect

import (
	"fmt"
	"github.com/prometheus/client_golang/prometheus"
)
//map[collectors]map[nodename]value,目前的collectors为:cpu,ram,iops.

var (
	Value float64
	Status string
	Ip string
	Cluster string
)

type Collector struct {}
//实现describe接口，Describe和Collect是制作指标两个重要接口，缺一不可
func (n Collector) Describe(ch chan<- *prometheus.Desc){}
//实现Collect接口，这里实现指标数据传输
func (n *Collector) Collect(ch chan<- prometheus.Metric){
	ch <- prometheus.MustNewConstMetric(
		prometheus.NewDesc(
			prometheus.BuildFQName("vm", "cklog", "interval"),
			//"A cpu metrics test.",
			fmt.Sprintf("A VM zckcluster ck log interval metrics."),
			[]string{"status","ip","cluster"},//labelskey
			nil,
		),
		prometheus.GaugeValue,
		Value,
		Status,Ip,Cluster,
	)
}
func Update(value float64,status,ip,cluster string)*Collector{
	//log.Printf("value:%f",value)
   Value=value
   Status=status
   Ip=ip
   Cluster=cluster
   return &Collector{}
}