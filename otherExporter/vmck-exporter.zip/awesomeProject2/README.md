使用说明：
打包成二进制文件后执行该文件
命令行参数：
1.dp(directory path),zck日志文件所在目录，必填参数
2.e(endpoint),监听端口，默认9031
3.h(help)查询命令行参数
例：
go build -o ./vm-ck-exporter ./main.go
./vm-ck-exporter --dp="/xxx/xxx/xx"