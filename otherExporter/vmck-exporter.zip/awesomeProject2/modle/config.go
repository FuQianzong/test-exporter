package modle

type Configuration struct {
	Localip   string `json:"localip"`
	Zkiplist  string `json:"zkiplist"`
	Zkrootdir string `json:"zkrootdir"`
	Ckdir     string `json:"ckdir"`
	Cluster string `json:"cluster"`
}
