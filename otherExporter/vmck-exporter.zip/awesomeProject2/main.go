package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"github.com/samuel/go-zookeeper/zk"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/gogf/gf/os/gcron"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"time"
	"vm-ck-exporter/collect"
	"vm-ck-exporter/modle"
)

func main() {
	ctx, _ := context.WithCancel(context.Background())
	configPath := flag.String("cp", "/", "config path")
	//dirpath := flag.String("dp", "/", "dir path")
	endpoint := flag.String("e", "9031", "endpoint")
	help := flag.Bool("h", false, "help")
	flag.Parse()
	if *help {
		flag.Usage()
		os.Exit(0)
	}
	//加载配置文件参数
	config := Cm(*configPath)
	log.Println("config:", config)
	//初始化zk


	en, err := gcron.Add("@every 10s", func() { Run(config, ctx) }, "vm-ck")
	if err != nil {
		log.Printf("cron job %s is err", en.Name)
		os.Exit(1)
	}
	go func() {
		if err := GetEndpoint(*endpoint).ListenAndServe(); err != nil {
			log.Printf("Error occur when start server %v\n", err)
		}
	}()
	for {
		select {
		case <-ctx.Done():
			if err := GetEndpoint(*endpoint).Shutdown(nil); err != nil {
				log.Println("Exiting the Web Service ")
				os.Exit(1) // failure/timeout shutting down the server gracefully
			}
		}
	}
}

//获取ck日志文件时间戳
func GetFileModTime(filepath string) int64 {
	relfilepath := strings.Replace(filepath, "\n", "", -1)
	/*	filepathlen:=len(strings.Split(relfilepath,""))
		log.Printf("filepath:%s,长度:%d\n",relfilepath,filepathlen)*/
	f, err := os.Open(relfilepath)
	if err != nil {
		log.Println("oper finle error", err)
	}
	defer f.Close()
	fi, err := f.Stat()
	if err != nil {
		log.Println(err)
	}
	return fi.ModTime().Unix()
}

//制作指标
func PromeMetricsHandle(collectvalue float64,status,localip,cluster string) error {
	reg := prometheus.NewPedanticRegistry()
	update:=collect.Update(collectvalue,status,localip,cluster)
	reg.MustRegister(update)
	gatherers := prometheus.Gatherers{
		//prometheus.DefaultGatherer,（这个为默认指标，可启用，也可不用）
		reg,
	}
	h := promhttp.HandlerFor(gatherers, promhttp.HandlerOpts{ErrorHandling: promhttp.ContinueOnError})
	http.HandleFunc("/metrics", func(w http.ResponseWriter, r *http.Request) { h.ServeHTTP(w, r) })
	return nil
}
func GetEndpoint(endpoint string) *http.Server {
	return &http.Server{Addr: ":" + endpoint}
}

//获取ck文件路径
func Cmd(dirpath string) string {
	unix := fmt.Sprintf("ls -lt %s/|grep \".*sys.*log\" |head -n 1 |awk '{print $9}'", dirpath)
	cmd := exec.Command("/bin/bash", "-c", unix)
	// 获取管道输入
	output, err := cmd.StdoutPipe()
	if err != nil {
		fmt.Println("无法获取命令的标准输出管道", err.Error())
	}
	// 执行Linux命令
	if err := cmd.Start(); err != nil {
		fmt.Println("Linux命令执行失败，请检查命令输入是否有误", err.Error())
	}
	// 读取所有输出
	bytes, err := ioutil.ReadAll(output)
	if err != nil {
		fmt.Println("打印异常，请检查")
	}

	if err := cmd.Wait(); err != nil {
		fmt.Println("Wait", err.Error())
	}
	filepath := fmt.Sprintf("%s/%s", dirpath, string(bytes))
	return filepath
}
func Run(conf modle.Configuration, ctx context.Context) {
	var interval float64 = -1
	var status ="follower"
	zkiplist := strings.Split(conf.Zkiplist, ",")
	zkrootdir:=conf.Zkrootdir
	localip:=conf.Localip
	ckdir:=conf.Ckdir
	cluster:=conf.Cluster
	nodeInfo,err := GetzkInfo(zkiplist, zkrootdir)
	if err!=nil{
		interval=-9999
		status="Unknown"
	}
	//log.Println("集群子节点信息:", nodeInfo)
	//信息处理，获取主节点ip
	leaderip := LeaderIp(nodeInfo)
	//log.Println("lederip:", leaderip)
	if localip == leaderip {
		status="leader"
		filePath := Cmd(ckdir)
		fileModeTime := GetFileModTime(filePath)
		timestamp := time.Unix(fileModeTime, 0)
		//log.Printf("文件时间戳：%d\n",fileModeTime)
		interval = time.Now().Sub(timestamp).Seconds()
	}
	if err := PromeMetricsHandle(interval,status,localip,cluster); err != nil {
		ctx.Done()
		log.Println(err)
	}
	log.Println("running succeed")
}
//获取配置信息
func Cm(configPath string) modle.Configuration {
	file, _ := os.Open(configPath)
	//defer file.Close()

	decoder := json.NewDecoder(file)
	conf := modle.Configuration{}
	err := decoder.Decode(&conf)
	if err != nil {
		fmt.Println(err)
	}
	return conf
}

//获取主节点ip
func LeaderIp(nodeinfo []string) string {
	if nodeinfo==nil{
		return "no ip"
	}
	min := 10000000000
	leader := ""
	for _, zkinfo := range nodeinfo {
		//elec@192.168.199.98_0000000003=>elec@192.168.199.98,0000000003
		zkinfo1 := strings.Split(zkinfo, "_")
		//elec@192.168.199.98,0000000003=>0000000003=>3
		num, err := strconv.Atoi(zkinfo1[1])
		if err != nil {
			log.Println(err)
		}
		if num < min {
			min = num
			leaderinfo := strings.Split(zkinfo1[0], "@")
			leader = leaderinfo[1]
		}
	}
	return leader
}
func GetzkInfo(zkiplist []string,nodeinfopath string)([]string,error){
	hosts := zkiplist
	retryTimes:=3

	retry:
	conn, _, err := zk.Connect(hosts, time.Second*2)
	if err != nil{
		log.Printf("zkconnect error:%s\n", err)
		return nil,err
	}
	defer conn.Close()
	childs, _, err := conn.Children(nodeinfopath)
	if err != nil&&retryTimes>0 {
		log.Println("Retry the connection")
		retryTimes--
		time.After(2*time.Second)
		goto retry
	}else if err!=nil&&retryTimes<=0{
		log.Println("zk connection fail")
		return nil,err
	}
	//fmt.Println(childs)
	return childs,nil
}
