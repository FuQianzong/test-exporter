package dbconnet

import (
	"fmt"
	"gorm.io/driver/clickhouse"
	"gorm.io/gorm"
	"log"
	"strconv"
	"time"
)

//var DB *gorm.DB
//connect database
func InitDB(envs map[string]string) (*gorm.DB,error){
	Retry(envs)
	restryTimes,_:=strconv.Atoi(envs["RESTRYTIMES"])
	counter:=restryTimes
	restryInterval,_:=time.ParseDuration(envs["RESTRYINTERVAL"])
	addr:=envs["ADDRESS"]
	dbName:=envs["DBNAME"]
	userName:=envs["USERNAME"]
	password:=envs["PASSWORD"]
	readTimeout:=10
	writeTimeout:=10
	dsn:=fmt.Sprintf("tcp://%s?database=%s&username=%s&password=%s&read_timeout=%d&write_timeout=%d",addr,dbName,userName,password,readTimeout,writeTimeout)

retry:
	db, err := gorm.Open(clickhouse.Open(dsn))
	if err != nil && restryTimes!=0{
		log.Println("failed to connect database")
		num:=counter-restryTimes+1
		log.Printf("正在尝试第%d重连，请等待%s\n",num,restryInterval)
		time.After(restryInterval)
		restryTimes--
		goto retry
	}
	return db,err
}

func Retry(envs map[string]string){
	//默认数据库连接最多重试3次，每次间隔10秒
	if _,ok:=envs["RESTRYTIMES"];!ok{
		envs["RESTRYTIMES"]="3"
	}
	if _,ok:=envs["RESTRYINTERVAL"];!ok{
		envs["RESTRYINTERVAL"]="10s"
	}
}
