package model

//存放clickhouse数据源表结构模型
import (
"time"
)

//源数据表的结构体resdata(resource data)
type MysqlPodDataH struct {
	Data_create_time                time.Time
	Insert_time                     time.Time
	K8s_cluster_code                string
	Namespace                       string
	Pod_name                        string
	Mysql_cluster_name              string
	Pod_restart_num                 int64
	Pod_status                      string
	Container_all_ready             int64
	Pod_cpu_limit_usage             float64
	Mysql_container_cpu_usage       float64
	Router_container_cpu_usage      float64
	Exporter_container_cpu_usage    float64
	Package_quota_cpu_usage         float64
	Pod_mem_limit_usage             float64
	Mysql_container_mem_usage       float64
	Router_container_mem_usage      float64
	Exporter_container_mem_usage    float64
	Package_quota_mem_usage         float64
	Data_disk_used_kb               float64
	Log_disk_used_kb                float64
	Data_disk_inode_usage           float64
	Log_disk_inode_usage            float64
	Data_disk_iostat_read_count     float64
	Data_disk_iostat_write_count    float64
	Data_disk_iostat_read_total_kb  float64
	Data_disk_iostat_write_total_kb float64
	Data_disk_iostat_await_ms       float64
	Data_disk_iostat_await_read_ms  float64
	Data_disk_iostat_await_write_ms float64
	Data_disk_iostat_util           float64
	Log_disk_iostat_read_count      float64
	Log_disk_iostat_write_count     float64
	Log_disk_iostat_read_total      float64
	Log_disk_iostat_write_total     float64
	Log_disk_iostat_await           float64
	Log_disk_iostat_await_r         float64
	Log_disk_iostat_await_w         float64
	Log_disk_iostat_util            float64
	Eth0_receiveBytesTotal          float64
	Eth0_receivePacketsTotal        float64
	Eth0_transmitBytesTotal         float64
	Eth0_transmitPacketsTotal       float64
	Eth1_receiveBytesTotal          float64
	Eth1_receivePacketsTotal        float64
	Eth1_transmitBytesTotal         float64
	Eth1_transmitPacketsTotal       float64
	Eth2_receiveBytesTotal          float64
	Eth2_receivePacketsTotal        float64
	Eth2_transmitBytesTotal         float64
	Eth2_transmitPacketsTotal       float64
}
/*type MysqlPodDataK8s struct {
	Execute_id                           string
	Insert_time                          time.Time
	K8s_cluster_code                     string
	Namespace                            string
	Pod_name                             string
	Mysql_cluster_name                   string
	Pod_container_count                  int64
	Mysql_container_cpu_limit_c          float64
	Mysql_container_cpu_request_c        float64
	Mysql_container_cpu_quota_m          float64
	Mysql_container_mem_limit_byte       float64
	Mysql_container_mem_request_byte     float64
	Mysql_container_mem_quota_byte       float64
	Router_container_cpu_limit_c         float64
	Router_container_cpu_request_c       float64
	Router_container_cpu_quota_m         float64
	Router_container_mem_limit_byte      float64
	Router_container_mem_request_byte    float64
	Router_container_mem_quota_byte      float64
	Exporter_container_cpu_limit_c       float64
	Exporter_container_cpu_request_c     float64
	Exporter_container_cpu_quota_m       float64
	Exporter_container_mem_limit_byte    float64
	Exporter_container_mem_request_byte  float64
	Exporter_container_mem_quota_byte    float64
	Data_disk_total_byte                 float64
	Log_disk_total_byte                  float64
}*/
type NodeData struct {
	Data_create_time           time.Time
	Insert_time                time.Time
	K8s_cluster_code           string
	Node_name                  string
	Node_ready                 string
	Node_schedule              string
	Up_time                    string
	Pod_num                    int64
	Container_num              int64
	Mysql_pod_count            int64
	Cpu_total_c                float64
	Cpu_usage                  float64
	Cpu_request_usage          float64
	Cpu_limit_usage            float64
	Mem_total_byte             float64
	Mem_usage                  float64
	Mem_request_usage          float64
	Mem_limit_usage            float64
	Nofile_usage               float64
	Nproc_process_count        float64
	Aio_usage                  float64
	Process_count              float64
	Time_correlation           float64
	Vf_total_count             float64
	Vf_unused_count            float64
	Origin_node_service_status string
	Openvswitch_service_status string
	Dnsmasq_service_status     string
	Docker_service_status      string
	Audit_is_off               string
	Local_disk_usage           float64
	Pool0_allocated_usage      float64
	Pool0_usage                float64
	Pool1_allocated_usage      float64
	Pool1_usage                float64
	Invalid_lv_count           float64
	Lv_vacancy_rate            float64
	Var_dir_usage              float64
	Cdd_docker_dir_usage       float64
	Opt_dir_usage              float64
	Kubelet_dir_usage          float64
	Sda_read_total_bytes       float64
	Sda_write_total_bytes      float64
	Sdb_read_total_bytes       float64
	Sdb_write_total_bytes      float64
	Sdc_read_total_bytes       float64
	Sdc_write_total_bytes      float64
	Bond0_receiveBytesTotal    float64
	Bond0_receivePacketsTotal  float64
	Bond0_transmitBytesTotal   float64
	Bond0_transmitPacketsTotal float64
	Bond1_receiveBytesTotal    float64
	Bond1_receivePacketsTotal  float64
	Bond1_transmitBytesTotal   float64
	Bond1_transmitPacketsTotal float64
	IopsReadsAndWrites float64
}
/*type NodeInfoK8s struct {
	Data_create_time        time.Time
	Insert_time             time.Time
	K8s_cluster_code        string
	Node_name               string
	Kernel_pid_max_count    float64
	Kernelip_forward_is_1   string
	Kernel_nosuid_not_have  string
	Pool0_lvm_size          float64
	Pool1_lvm_size          float64
}*/

//将结构体和表名为t_mysql_pod_data_h_bak的数据表绑定
func (mpdh MysqlPodDataH) TableName() string {
	return "t_mysql_pod_data_h"
}
/*func (mpdk MysqlPodDataK8s) TableName()string{
	return "t_mysql_pod_data_k8s"
}*/
func (nd NodeData) TableName()string{
	return "t_node_data"
}
/*func (nik NodeInfoK8s) TableName()string {
	return "t_node_info_k8s"
}*/
