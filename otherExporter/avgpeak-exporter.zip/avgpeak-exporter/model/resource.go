package model

import "time"

type Node struct {
	It time.Time//Insert_time
	NodeName string
	CpuUsage float64
	MemUsage float64
	IopsReadsAndWrites float64

}

type Pod struct {
	It time.Time//Insert_time
	PodName string
	PodCpuLimitUsage float64
	odMemLimitUsage float64
}