package model

import "time"

type MysqlPodDataHResult struct {
	//default field:
	InsertTime time.Time `gorm:"column:Insert_time"`
	PodName string
	PodCpuLimitUsage string
	PodMemLimitUsage string
}


type NodeDataResult struct {
	//default field:
	InsertTime time.Time `gorm:"column:Insert_time"`
	NodeName string
	CpuUsage float64
	MemUsage float64
	IopsReadsAndWrites float64
}

func (mpdhr MysqlPodDataHResult) TableName()string{
	return "t_avg_pod_mysql"
}
func (ndr NodeDataResult) TableName()string{
	return "t_avg_node_data"
}

