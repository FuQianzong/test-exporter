package collector

import (
	"awesomeProject2/model"
	"fmt"
	"github.com/prometheus/client_golang/prometheus"
	"sync"
)
//map[collectors]map[nodename]value,目前的collectors为:cpu,ram,iops.
var Collectorset=make(map[string]map[string]float64)

type NodeCollector struct {}
//实现describe接口，Describe和Collect是制作指标两个重要接口，缺一不可
func (n NodeCollector) Describe(ch chan<- *prometheus.Desc){}
//实现Collect接口，这里实现指标数据传输
func (n *NodeCollector) Collect(ch chan<- prometheus.Metric){
	wg:=sync.WaitGroup{}
	wg.Add(len(Collectorset))
	for collectorName,collectorValues:=range Collectorset{
		go func(collectorName string,collectorValues map[string]float64) {
		PromeMetricsBuild(collectorName,collectorValues,ch)
		wg.Done()
		}(collectorName,collectorValues)
	}
	wg.Wait()
}
//更新指标数据，新增指标只需在此处添加
func Update(nodedataset []model.Node)*NodeCollector{
	var cpudata=make(map[string]float64)
	var ramdata=make(map[string]float64)
	var iopsdata=make(map[string]float64)
	var collectors=make(map[string]map[string]float64)
	var mu sync.RWMutex
	wg:=sync.WaitGroup{}
	for _,v:=range nodedataset{
		wg.Add(1)
		go func(v model.Node) {
			mu.Lock()
			defer mu.Unlock()
			cpudata[v.NodeName]=v.CpuUsage
			ramdata[v.NodeName]=v.MemUsage
			iopsdata[v.NodeName]=v.IopsReadsAndWrites
			wg.Done()
		}(v)
	}
	wg.Wait()
	collectors["cpu"]=cpudata
	collectors["ram"]=ramdata
	collectors["iops"]=iopsdata
	Collectorset=collectors
	return &NodeCollector{}
}
//指标创建
func PromeMetricsBuild(collectName string,collectorValues map[string]float64,ch chan<- prometheus.Metric){
	wg:=sync.WaitGroup{}
	for nodename,collectdata:=range collectorValues{
		wg.Add(1)
		go func(nodename string,collectdata float64) {
		ch <- prometheus.MustNewConstMetric(
			prometheus.NewDesc(
				prometheus.BuildFQName("avgpeak", collectName, "averagepeak_percent"),
				//"A cpu metrics test.",
				fmt.Sprintf("A %s metrics test.",collectName),
				[]string{"node_name"},//labelskey
				nil,
			),
			prometheus.GaugeValue,
			collectdata,
			nodename,//labelsvalue
		)
		wg.Done()
		}(nodename,collectdata)
	}
	wg.Wait()
}