package main

import (
	"awesomeProject2/collector"
	"awesomeProject2/model"
	"context"
	"fmt"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"gorm.io/gorm"
	"log"
	"net/http"
	"os"
	"regexp"
	"strings"
	"sync"
)

const (
	Pmaptablename="t_avg_pod_mysql"
	Pmrestablename="t_mysql_pod_data_h"
	Ndaptablename="t_avg_node_data"
	Ndrestablename="t_node_data"
	Group1="pod_name"
	Group2="node_name"
)

//检查数据表是否存在
func CheckTable(db *gorm.DB)error{
	//the source table
	mpdh:=db.Migrator().HasTable(&model.MysqlPodDataH{})
	nd:=db.Migrator().HasTable(&model.NodeData{})
	mpdhr:=db.Migrator().HasTable(&model.MysqlPodDataHResult{})
	ndr:=db.Migrator().HasTable(&model.NodeDataResult{})
	if !mpdh||!nd||!mpdhr||!ndr{
		log.Println("Check resource table fail")
	}
	return nil
}
//运行任务
func Run(tablefieldset map[string][]string,db *gorm.DB,ctx context.Context){
	nodedataset,err:=SqlExec(tablefieldset,db)
	if err!=nil{
		ctx.Done()
		log.Printf("SqlExec error:%s\n",err)
		os.Exit(1)
	}
	if err:=PromeMetricsHandle(nodedataset);err!=nil{
		ctx.Done()
		log.Printf("promeMetricsHandle error:%s\n",err)
		os.Exit(1)
	}
	log.Println("running success")
}
//字段分类,分node和pod的数据
func ClassifyField(envset map[string]string)map[string][]string{
	tablefield:=make(map[string][]string)
	var pmfield,ndfield []string
	for key,value:=range envset{
		if ok,_:=regexp.MatchString("^PM_",key);ok{
			pmfield=append(pmfield,value)
		}
		if ok,_:=regexp.MatchString("^ND_",key);ok{
			ndfield=append(ndfield,value)
		}
	}
	if len(ndfield)>0{tablefield[Group2]=ndfield}
	if len(pmfield)>0{tablefield[Group1]=pmfield}
	return tablefield
}
//拼接成查找原始数据表计算均峰值的sql语句
func Newselectsql(calstr []string,restablename,group string) string{
	nowTime:="now()" //当前时间
	interval:="subtractMinutes(now(), 5)" //间隔时间
	inserTime:="Insert_time"
	resstrs:=fmt.Sprintf(strings.Join(Avgclause(calstr),","))
	sqlstatement:=fmt.Sprintf("select %s,%s,%s from %s where(%s between %s and %s) group by %s",
		nowTime,
		group,
		resstrs,
		restablename,
		inserTime,
		interval,
		nowTime,
		group)
	return sqlstatement
}
//拼接成查询均峰值表数据sql语句
func GetMetricsDatasql(calstr []string,restablename,group string) string{
	nowTime:="now()" //当前时间
	interval:="subtractSeconds(now(), 5)" //间隔时间
	inserTime:="Insert_time"
	resstrs:=fmt.Sprintf(strings.Join(calstr,","))
	sqlstatement:=fmt.Sprintf("select %s as it,%s,%s from %s where(%s between %s and %s)",
		nowTime,
		group,
		resstrs,
		restablename,
		inserTime,
		interval,
		nowTime)
	return sqlstatement
}
//拼接成sql字符串平均值子句
func Avgclause(ss []string)[]string{
	//sum(if(pod_cpu_limit_usage > 0, pod_cpu_limit_usage, 0))/count(if(pod_cpu_limit_usage > 0, 1, 0.000001))
	avgclauses:=[]string{}
	for _,s:=range ss{
		avgclause:=fmt.Sprintf("sum(if(greaterOrEquals(%s,0), %s, 0))/sum(if(greaterOrEquals(%s,0), 1, 0.000001))",s,s,s)
		avgclauses=append(avgclauses,avgclause)
	}
	return avgclauses
}
//数据库操作
func SqlExec(tablefieldset map[string][]string,db *gorm.DB)([]model.Node,error){
	nodedataset:=[]model.Node{}
	wg:=sync.WaitGroup{}
	tablefieldsetlen:=len(tablefieldset)
	wg.Add(tablefieldsetlen)
	for k,v:=range tablefieldset{
		go func(k string,v []string){
		if k==Group2{
			if err:=InsertSql(k,Ndrestablename,Ndaptablename,v,db);err!=nil{
				log.Printf("nd data insertion error:%s\n",err)
			}
			nodedatasql:=GetMetricsDatasql(v,Ndaptablename,Group2)
			tx:=db.Raw(nodedatasql).Scan(&nodedataset)
			if tx.Error!=nil{
				log.Printf("nd data query error:%s\n",tx.Error)
			}
			wg.Done()
		}
		if k==Group1{
			if err:=InsertSql(k,Pmrestablename,Pmaptablename,v,db);err!=nil{
				log.Printf("nd data insertion error:%s\n",err)
			}
			wg.Done()
		}
		}(k,v)
	}
	wg.Wait()
	//log.Println(time.Now().Unix(),"sqlexec end")
	return nodedataset,nil
}
//生成prometheus指标
func PromeMetricsHandle(nodedataset []model.Node) error{
	reg := prometheus.NewPedanticRegistry()
	reg.MustRegister(collector.Update(nodedataset))
	gatherers := prometheus.Gatherers{
		//prometheus.DefaultGatherer,（这个为默认指标，可启用，也可不用）
		reg,
	}
	h := promhttp.HandlerFor(gatherers, promhttp.HandlerOpts{ErrorHandling: promhttp.ContinueOnError})
	http.HandleFunc("/metrics", func(w http.ResponseWriter, r *http.Request) {h.ServeHTTP(w, r)})
	return nil
}
//返回一个端口
func GetEndpoint()*http.Server{
	return 	&http.Server{Addr: ":8080"}
}

func InsertSql(groupName,resTableName,apTableName string,groupField []string,db *gorm.DB)error{
	selectsql:=Newselectsql(groupField,resTableName,groupName)
	insertintosql:=fmt.Sprintf("insert into %s(Insert_time,%s,%s) %s",apTableName,groupName,strings.Join(groupField,","),selectsql)
	//log.Println(insertintosql)
	db.Exec(insertintosql)
	return nil
}
//测试用的环境变量
func Envtest()(map[string]string,error){
    envset1:=make(map[string]string)
    envset1["DBNAME"]=""
    envset1["USERNAME"]=""
    envset1["PASSWORD"]=""
    envset1["ADDRESS"]=""
    envset1["PM_PODCPUUSAGE"]=""
    envset1["PM_PODMEMUSAGE"]=""
    envset1["ND_CPUUSAGE"]=""
    envset1["ND_MEMUSAGE"]=""
    envset1["ND_IOPS"]=""
	return envset1,nil
}
