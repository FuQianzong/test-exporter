package main

import (
	"awesomeProject2/dbconnet"
	"awesomeProject2/env"
	"context"
	"github.com/gogf/gf/os/gcron"
	"log"
	"os"
)

func main(){
	ctx,cancel:=context.WithCancel(context.Background())
	//导入环境变量
	envset,err:=env.GetEnvs()
	//测试用的
	//envset,err:=Envtest()
	if err!=nil{
		log.Printf("fail to get ENV:%s\n",err)
		cancel()
		os.Exit(1)
	}
	log.Println("ENV were load the success")
	//数据库初始化
	db,err:=dbconnet.InitDB(envset)
	if err!=nil{
		log.Printf("Connection clickhouse err:%s\n",err)
		cancel()
		os.Exit(1)
	}
	log.Println("Database connection succeeded")
	//检查表
	err=CheckTable(db)
	if err!=nil{
		log.Printf("Check datatable fail:%s",err)
		cancel()
		os.Exit(1)
	}
	log.Println("The data table is fine")
	//字段分类
	tablefieldset:=ClassifyField(envset)
	//定时任务
	en,err:=gcron.Add("@every 30s", func() { Run(tablefieldset,db,ctx) },"avgpeak")
	if err!=nil{
		log.Printf("cron job %s is err",en.Name)
		cancel()
		os.Exit(1)
	}
	go func() {
	if err := GetEndpoint().ListenAndServe(); err != nil {
		log.Printf("Error occur when start server %v\n", err)
	}
	}()
	for {
		select {
		case <-ctx.Done():
			if err := GetEndpoint().Shutdown(nil); err != nil {
				log.Println("Exiting the Web Service ")
				os.Exit(1) // failure/timeout shutting down the server gracefully
			}
		}
	}

}




