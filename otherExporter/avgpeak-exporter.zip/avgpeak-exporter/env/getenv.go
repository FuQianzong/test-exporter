package env
//获取环境变量

import (
	"os"
	"strings"
)

func GetEnvs() (map[string]string,error){
	envset:=map[string]string{}
	envs := os.Environ()
	for _, env := range envs {
		parts := strings.Split(env, "=")
		envset[parts[0]]=parts[1]
	}
	return envset,nil
}